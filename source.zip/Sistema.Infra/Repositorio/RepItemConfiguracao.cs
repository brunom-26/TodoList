﻿//using Sistema.Domain.Entities;
//using Sistema.Domain.Interfaces.IRepository;
//using System.Configuration;
//using System.Data;
//using System.Data.SqlClient;

//namespace Sistema.Infra.Repositorio
//{
//    public class RepItemConfiguracao : RepositoryBase<ItemConfiguracao>, IRepItemConfiguracao
//    {
//        private static readonly IDbConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnSistema"].ConnectionString);

//        public RepItemConfiguracao() : base(Conn)
//        {
            
//        }
//    }
//}

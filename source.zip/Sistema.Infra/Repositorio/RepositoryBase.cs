﻿using System;
using System.Collections.Generic;
using Sistema.Domain.Interfaces.IRepository;
using NHibernate;

namespace Sistema.Infra.Repositorio
{
    public abstract class RepositoryBase<T> : IRepositoryBase<T> where T : class
    {
        public T BuscarPor(long id)
        {
            return SessionFactory.ObterSessao().Get<T>(id);
        }

        public IList<T> BuscarTodos()
        {
            ISession sessao =  SessionFactory.ObterSessao();

            ICriteria criteria = sessao.CreateCriteria(typeof(T));

            return criteria.List<T>();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public void Remover(T entidade)
        {
            ISession sessao = SessionFactory.ObterSessao();
            sessao.Delete(entidade);
            sessao.Flush();
        }

        public void Salvar(T entidade)
        {
            ISession sessao = SessionFactory.ObterSessao();
            sessao.SaveOrUpdate(entidade);
            sessao.Flush();
        }
    }
}

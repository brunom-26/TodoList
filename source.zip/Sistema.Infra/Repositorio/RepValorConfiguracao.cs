﻿//using Sistema.Domain.Entities;
//using Sistema.Domain.Interfaces.IRepository;
//using System.Collections.Generic;
//using System.Configuration;
//using System.Data;
//using System.Data.SqlClient;
//using System.Linq;

//namespace Sistema.Infra.Repositorio
//{
//    public class RepValorConfiguracao : RepositoryBase<ValorConfiguracao>, IRepValorConfiguracao
//    {
//        private static readonly IDbConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnSistema"].ConnectionString);

//        public RepValorConfiguracao()
//            : base(Conn)
//        {
            
//        }

//        public ValorConfiguracao GetByIdConfiguracao(long idConfiguracao)
//        {
//            var valor = Find(x => x.IdItemConfiguracao == idConfiguracao && (x.Ativo)).OrderByDescending(x => x.Id).FirstOrDefault();

//            if (valor != null && valor.Id > 0)
//                return GetById(valor.Id);
//            else
//                return new ValorConfiguracao();
//        }
//    }
//}

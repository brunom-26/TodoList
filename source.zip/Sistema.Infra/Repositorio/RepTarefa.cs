﻿using Sistema.Domain.Entities;
using Sistema.Domain.Interfaces.IRepository;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sistema.Domain.DTO;
using NHibernate;
using NHibernate.Criterion;
using NHibernate.Transform;

namespace Sistema.Infra.Repositorio
{
    public class RepTarefa : RepositoryBase<Tarefa>, IRepTarefa
    {
        public IList<DTOTarefa> ListarTarefas(DateTime data, StatusTarefa status)
        {
            ISession sessao = SessionFactory.ObterSessao();

            ICriteria criteria = sessao.CreateCriteria(typeof(Tarefa), "T").CreateAlias("TipoTarefa", "TT");

            criteria.SetProjection(Projections.ProjectionList()
                .Add(Projections.Property("T.id"), "_id")
                .Add(Projections.Property("T.DataTarefa"), "_dataTarefa")
                .Add(Projections.Property("T.TextoTarefa"), "_textoTarefa")
                .Add(Projections.Property("TT.NomeTipo"), "_nomeTipoTarefa")
                .Add(Projections.Property("TT.id"), "_idTipoTarefa")
                .Add(Projections.Property("T.StatusTarefa"), "_statusTarefa")
                );

            criteria.Add(Restrictions.Eq("T.StatusTarefa", status));

            criteria.Add(Restrictions.Eq("T.DataTarefa", data));

            return criteria.SetResultTransformer(Transformers.AliasToBean(typeof(DTOTarefa))).List<DTOTarefa>();
        }
    }
}

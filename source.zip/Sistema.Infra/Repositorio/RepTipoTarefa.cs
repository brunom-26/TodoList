﻿using Sistema.Domain.Entities;
using Sistema.Domain.Interfaces.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sistema.Domain.DTO;
using NHibernate.Transform;
using NHibernate.Criterion;
using NHibernate;

namespace Sistema.Infra.Repositorio
{
    public class RepTipoTarefa : RepositoryBase<TipoTarefa>, IRepTipoTarefa
    {
        public IList<DTOTipoTarefa> BuscarTiposTarefa()
        {
            ISession sessao = SessionFactory.ObterSessao();

            ICriteria criteria = sessao.CreateCriteria(typeof(TipoTarefa), "TT");

            criteria.SetProjection(Projections.ProjectionList()
                    .Add(Projections.Property("TT.Id"), "_id")
                    .Add(Projections.Property("TT.NomeTipo"), "_nomeTipoTarefa")
                );

            return criteria.SetResultTransformer(Transformers.AliasToBean(typeof(DTOTipoTarefa))).List<DTOTipoTarefa>();
        }
    }
}

﻿//using Sistema.Domain.Interfaces.IRepository;
//using System;
//using System.Data.SqlClient;

//namespace Sistema.Infra.Repositorio
//{
//    public class UnityOfWork : IUnityOfWork
//    {
//        private readonly RepAcordo _repAcordo;
//        private SqlConnection _conn;
//        private SqlTransaction _t;
//        private RepAcordoLote _repLotesAcordo;

//        public UnityOfWork(string connectionString)
//        {
//            _conn = new SqlConnection(connectionString);
//            _conn.Open();
//            _t = _conn.BeginTransaction();

//            _repAcordo = new RepAcordo(_conn, _t);
//            _repLotesAcordo = new RepAcordoLote(_conn, _t);
//        }

//        public IRepAcordo Acordos
//        {
//            get { return _repAcordo; }
//        }

//        public IRepAcordoLote LotesAcordo
//        {
//            get { return _repLotesAcordo; }
//        }

//        public void Complete()
//        {
//            _t.Commit();
//        }

//        public void Dispose()
//        {
//            _t.Dispose();
//            _conn.Dispose();
//        }
//    }
//}

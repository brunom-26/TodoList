﻿using FluentNHibernate.Mapping;
using Sistema.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Infra.Mapeamento
{
    public class MapTipoTarefa : ClassMap<TipoTarefa>
    {
        public MapTipoTarefa()
        {
            Table("tipo_tarefa");
            Id(x => x.Id).Column("id");
            Map(x => x.DataCriacao).Column("dt_criacao").Not.Nullable();
            Map(x => x.NomeTipo).Column("str_nome_tipo").Length(100).Not.Nullable();
        }
    }
}

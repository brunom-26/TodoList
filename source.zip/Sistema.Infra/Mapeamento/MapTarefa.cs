﻿
using Sistema.Domain.Entities;
using FluentNHibernate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate.Mapping;

namespace Sistema.Infra.Mapeamento
{
    public class MapTarefa : ClassMap<Tarefa>
    {
        public MapTarefa()
        {
            Table("tarefa");
            Id(x => x.Id).Column("id");
            Map(x => x.DataCriacao).Column("dt_criacao").Not.Nullable();
            Map(x => x.TextoTarefa).Column("str_texto_tarefa").Length(2000).Not.Nullable();
            Map(x => x.DataTarefa).Column("dt_tarefa").Not.Nullable();
            References(x => x.TipoTarefa).Column("id_tipo_tarefa").Not.Nullable();
            Map(x => x.StatusTarefa).Column("enum_status_tarefa").Not.Nullable();

        }
    }
}

﻿using FluentNHibernate.Cfg;
using FluentNHibernate.Conventions.Helpers;
using FluentNHibernate.Conventions.Inspections;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Infra
{
    public class SessionFactory
    {
        private static ISessionFactory _sessionFactory;

        internal static ISessionFactory CriarSessionFactory()
        {
            if (_sessionFactory != null)
            {
                return _sessionFactory;
            }
            else
            {
                string caminhoConfigNhibernate = "";

                if (ConfigurationManager.AppSettings["arquivoCfgNHibernate"] != null)
                    caminhoConfigNhibernate = ConfigurationManager.AppSettings["arquivoCfgNHibernate"].ToString();
                
                NHibernate.Cfg.Configuration config = new NHibernate.Cfg.Configuration().Configure(caminhoConfigNhibernate);

                ISessionFactory newSessionFactory =
                   Fluently.Configure(config)
                       .Mappings(m =>
                                 m.FluentMappings
                                     .AddFromAssemblyOf<SessionFactory>()
                                     .Conventions.AddFromAssemblyOf<SessionFactory>()
                                     .Conventions.Add(DefaultAccess.CamelCaseField(CamelCasePrefix.Underscore)))
                       .BuildSessionFactory();

                //SchemaExport exp = new SchemaExport(config);
                //exp.Drop(true, true);
                //exp.Create(true, true);
                
                _sessionFactory = newSessionFactory;

                return _sessionFactory;
            }

        }

   
        public static ISession ObterSessao()
        {
            if (_sessionFactory == null)
            {
                CriarSessionFactory();
            }

            if (!NHibernate.Context.WebSessionContext.HasBind(_sessionFactory))
                NHibernate.Context.WebSessionContext.Bind(_sessionFactory.OpenSession());

            return _sessionFactory.GetCurrentSession();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.CrossCutting.Util
{
    public static class Conversor
    {
        public static int? ConverterInteiro(string valor)
        {
            int retorno = 0;

            if (!int.TryParse(valor, out retorno))
                return null;

            return retorno;
        }

        public static decimal? ConverterDecimal(string valor)
        {
            decimal retorno = 0;

            if (!decimal.TryParse(valor, out retorno))
                return null;

            return retorno;
        }

        public static bool? ConverterBoolean(string valor)
        {
            bool retorno = false;

            if (valor.ToUpper() == "SIM")
                valor = "True";
            else if (valor.ToUpper() == "NÃO")
                valor = "false";


            if (!bool.TryParse(valor, out retorno))
                return null;

            return retorno;
        }
    }
}

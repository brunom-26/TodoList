﻿using FluentValidation.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.CrossCutting.Util
{
    public static class Util
    {
        public static string CriarMensagemErroPadrao(ValidationResult results)
        {
            string mensagemErro = "";

            //TODO - Evoluir mensagem de erro a ser demonstrada para o usuário

            foreach (ValidationFailure falha in results.Errors)
                mensagemErro += falha.ErrorMessage;

            return mensagemErro;
        }

        public static IEnumerable<string> SplitByLength(string str, int maxLength)
        {
            int index = 0;
            while (true)
            {
                if (index + maxLength >= str.Length)
                {
                    yield return str.Substring(index);
                    yield break;
                }
                yield return str.Substring(index, maxLength);
                index += maxLength;
            }
        }
    }
}

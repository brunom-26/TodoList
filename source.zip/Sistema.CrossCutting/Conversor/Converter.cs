﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.CrossCutting.Conversor
{
    public static class Converter
    {
        public static long ParaLong(string valor)
        {
            long retorno = 0;

            long.TryParse(valor, out retorno);

            return retorno;
        }
        public static int ParaInteiro(string valor)
        {
            int retorno = 0;

            int.TryParse(valor, out retorno);

            return retorno;
        }

        public static bool ParaBool(string valor)
        {
            bool retorno = false;

            if (valor == "1")
                return true;
            if (valor == "0")
                return false;

            bool.TryParse(valor, out retorno);

            return retorno;
        }
        public static DateTime? ParaDatetime(string valor, string format)
        {
            DateTime? retorno = null;

            DateTime dtParse = DateTime.MinValue;

            if (string.IsNullOrEmpty(format))
            {
                //if (DateTime.TryParse(valor, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out dtParse))
                if (DateTime.TryParse(valor, out dtParse))
                    retorno = dtParse;
            }
            else
            {
                if (DateTime.TryParseExact(valor,
                           format,
                           System.Globalization.CultureInfo.InvariantCulture,
                           System.Globalization.DateTimeStyles.None,
                           out dtParse))
                {
                    retorno = dtParse;
                }
            }

            return retorno;
        }
        public static decimal? ParaDecimal(string valor)
        {
            decimal retorno = 0;

            if (!decimal.TryParse(valor, out retorno))
                return null;

            return retorno;
        }

        public static decimal? ParaDecimal(string valor, string valorCasaDecimais)
        {
            decimal retorno = 0;
            
            valor = valor + "," + valorCasaDecimais;

            if (!decimal.TryParse(valor, out retorno))
            {
                valor = valor.Replace(",",".");

                if (!decimal.TryParse(valor, out retorno))
                   return null;
            }

            return retorno;
        }
    }
}

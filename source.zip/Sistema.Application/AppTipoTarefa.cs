﻿using Sistema.Domain.Interfaces.IApplication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sistema.Domain.Entities;
using Sistema.Domain.Interfaces.IRepository;
using Sistema.Infra.Repositorio;

namespace Sistema.Application
{
    public class AppTipoTarefa : IAppTipoTarefa
    {
        IRepTipoTarefa _repTipoTArefa;

        public AppTipoTarefa()
        {
            _repTipoTArefa = new RepTipoTarefa();
        }

        public IList<TipoTarefa> BuscarTodos()
        {
            return _repTipoTArefa.BuscarTodos();
        }

        public TipoTarefa BuscarPor(long id)
        {
            return _repTipoTArefa.BuscarPor(id);
        }

        public void Remover(long id)
        {
            TipoTarefa tipoTarefa =_repTipoTArefa.BuscarPor(id);
            _repTipoTArefa.Remover(tipoTarefa);
        }

        public void Salvar(TipoTarefa tipoTarefa)
        {
            _repTipoTArefa.Salvar(tipoTarefa);
        }
    }
}

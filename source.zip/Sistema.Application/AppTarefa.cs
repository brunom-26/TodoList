﻿using Sistema.Domain.DTO;
using Sistema.Domain.Entities;
using Sistema.Domain.Interfaces.IApplication;
using Sistema.Domain.Interfaces.IRepository;
using Sistema.Infra.Repositorio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Application
{
    public class AppTarefa : IAppTarefa
    {
        IRepTarefa _repTarefa;
        IRepTipoTarefa _repTipoTarefa;

        public AppTarefa()
        {
            _repTarefa = new RepTarefa();
            _repTipoTarefa = new RepTipoTarefa();
        }

        public void Salvar(Tarefa tarefa)
        {
            _repTarefa.Salvar(tarefa);
        }

        public void Encerrar(long id)
        {
            Tarefa tarefa = _repTarefa.BuscarPor(id);
            tarefa.StatusTarefa = StatusTarefa.Encerrada;

            _repTarefa.Salvar(tarefa);
        }

        public void Cancelar(long id)
        {
            Tarefa tarefa = _repTarefa.BuscarPor(id);
            tarefa.StatusTarefa = StatusTarefa.Cancelada;

            _repTarefa.Salvar(tarefa);
        }

        public IList<DTOTarefa> ListarTarefas(DateTime data, StatusTarefa status)
        {
            return _repTarefa.ListarTarefas(data, status);
        }

        public void Remover(long id)
        {
            Tarefa tarefa = _repTarefa.BuscarPor(id);

            _repTarefa.Remover(tarefa);
        }

        public Tarefa BuscarPor(long id)
        {
            return _repTarefa.BuscarPor(id);
        }

        public IList<DTOTipoTarefa> BuscarTiposTarefa()
        {
            return _repTipoTarefa.BuscarTiposTarefa();
        }
    }
}

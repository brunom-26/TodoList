﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Sistema.Application;
using Sistema.Domain.Entities;
using Sistema.Domain.Interfaces.IApplication;
using System;
using System.Linq;
using System.Collections.Generic;

namespace Sistema.Testes
{
    [TestClass]
    public class TarefaTest
    {
        [TestMethod]
        [ExpectedException(typeof(Exception), "A data da tarefa deve ser maior ou igual a data atual.")]
        public void validar_tarefa_data_menor_atual()
        {
            TipoTarefa tipoTarefa = new TipoTarefa("Tipo Tarefa Teste");
            Tarefa tarefa = new Tarefa(DateTime.Today.AddDays(-1), "Teste tarefa com data menor que a atual", tipoTarefa);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception), "O tipo de tarefa deve ser selecionado.")]
        public void validar_tarefa_sem_tipo_tarefa()
        {
            Tarefa tarefa = new Tarefa(DateTime.Today.AddDays(-1), "Teste tarefa sem tipo de tarefa.", null);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception), "Informar um texto para a tarefa.")]
        public void validar_tarefa_sem_texto()
        {
            TipoTarefa tipoTarefa = new TipoTarefa("Tipo Tarefa Teste");
            Tarefa tarefa = new Tarefa(DateTime.Today.AddDays(-1), "", tipoTarefa);
        }

    }
}

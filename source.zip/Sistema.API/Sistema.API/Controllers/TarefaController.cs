﻿using Sistema.Application;
using Sistema.Domain.DTO;
using Sistema.Domain.Entities;
using Sistema.Domain.Interfaces.IApplication;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Sistema.API.Controllers
{
    [RoutePrefix("Tarefa")]
    public class TarefaController : ApiController
    {
        [HttpPost]
        [Route("Salvar")]
        public HttpResponseMessage Salvar(DTOFormTarefa dtoTarefa)
        {
           try
            {
                IAppTarefa appTarefa = new AppTarefa();
                IAppTipoTarefa appTipoTarefa = new AppTipoTarefa();

                Tarefa tarefa = appTarefa.BuscarPor(dtoTarefa.id);

                if (tarefa != null)
                {
                    tarefa.TextoTarefa = dtoTarefa.TextoTarefa;
                    tarefa.DataTarefa = Convert.ToDateTime(dtoTarefa.DataTarefa);
                }
                else
                {
                    TipoTarefa tipoTarefa = appTipoTarefa.BuscarPor(dtoTarefa.IdTipoTarefa);
                    tarefa = new Tarefa(Convert.ToDateTime(dtoTarefa.DataTarefa), dtoTarefa.TextoTarefa, tipoTarefa);
                }
                
                appTarefa.Salvar(tarefa);

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
               return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        
        [HttpPut]
        [Route("Encerrar/{id}")]
        public HttpResponseMessage Encerrar(int id)
        {
            
            try
            {
                IAppTarefa appTarefa = new AppTarefa();
                appTarefa.Encerrar(id);
                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
            
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPut]
        [Route("Cancelar/{id}")]
        public HttpResponseMessage Cancelar(int id)
        {
            try
            {
                IAppTarefa appTarefa = new AppTarefa();
                appTarefa.Cancelar(id);
                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {

                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpDelete]
        [Route("Excluir/{id}")]
        public HttpResponseMessage Excluir(int id)
        {
            try
            {
                IAppTarefa appTarefa = new AppTarefa();
                appTarefa.Remover(id);
                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {

                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet]
        [Route("Listar/{status}")]
        public HttpResponseMessage Listar(StatusTarefa status)
        {
            try
            {
                IAppTarefa appTarefa = new AppTarefa();

                IList<DTOTarefa> listaDtoTarefa = appTarefa.ListarTarefas(DateTime.Today, status);

                return Request.CreateResponse(HttpStatusCode.OK, listaDtoTarefa);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet]
        [Route("BuscarTiposTarefa")]
        public HttpResponseMessage BuscarTiposTarefa()
        {
            try
            {
                IAppTarefa appTarefa = new AppTarefa();

                IList<DTOTipoTarefa> listaDtoTarefa = appTarefa.BuscarTiposTarefa();

                return Request.CreateResponse(HttpStatusCode.OK, listaDtoTarefa);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

    }
}

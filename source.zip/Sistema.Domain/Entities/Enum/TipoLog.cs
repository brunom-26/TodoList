﻿
namespace Sistema.Domain.Entities.Enum
{
    public enum TipoLog
    {
        //1 Alerta, 2 Erro, 3 Sucesso
        Alerta = 1,
        Erro,
        Sucesso
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Domain.Entities.Enum
{
    public enum Status
    {
        Bloqueado = 0,
        Ativo = 1
    }
}

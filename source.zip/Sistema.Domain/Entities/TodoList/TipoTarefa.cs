﻿
namespace Sistema.Domain.Entities
{
    public class TipoTarefa : BaseClass
    {
        private string _nomeTipo;

        public virtual string NomeTipo
        {
            get
            {
                return _nomeTipo;
            }
            set
            {
                _nomeTipo = value;
            }
        }

        protected TipoTarefa() {

        }

        public TipoTarefa(string nomeTipo)
        {
            NomeTipo = nomeTipo;
        }
    }
}

﻿using System;

namespace Sistema.Domain.Entities
{
    public class Tarefa : BaseClass
    {
        private DateTime _dataTarefa;
        private string _textoTarefa;
        private TipoTarefa _tipoTarefa;
        private StatusTarefa _statusTarefa;

        public virtual DateTime DataTarefa {
            get {
                return _dataTarefa;
            }
            set {
                if (value < DateTime.Today)
                    throw new Exception("A data da tarefa deve ser maior ou igual a data atual.");

                _dataTarefa = value;
            }
        }

        public virtual string TextoTarefa
        {
            get
            {
                return _textoTarefa;
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Informar um texto para a tarefa.");

                _textoTarefa = value;
            }
        }

        
        public virtual TipoTarefa TipoTarefa
        {
            get
            {
                return _tipoTarefa;
            }
            set
            {
                if (value == null)
                    throw new Exception("O tipo de tarefa deve ser selecionado.");

                _tipoTarefa = value;
            }
        }
        
        public virtual StatusTarefa StatusTarefa
        {
            get
            {
                return _statusTarefa;
            }
            set
            {
                _statusTarefa = value;
            }
        }

        protected Tarefa()
        {
        }

        public Tarefa(DateTime dataTarefa, string textoTarefa, TipoTarefa tipoTarefa)
        {
            DataTarefa = dataTarefa;
            TextoTarefa = textoTarefa;
            TipoTarefa = tipoTarefa;
            StatusTarefa = StatusTarefa.Pendente;
        }

    }
}

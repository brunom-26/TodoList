﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Domain.Entities
{
    public enum StatusTarefa
    {   
        Pendente = 1,
        Encerrada = 2,
        Cancelada = 3
    }
}

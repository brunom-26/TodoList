﻿using Sistema.Domain.Entities.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Domain.Entities
{
    public abstract class BaseClass
    {
        public BaseClass()
        {
            this.DataCriacao = DateTime.Now;
        }

        private long _id = 0;
        private DateTime _dataCriacao;

        public virtual long Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public virtual DateTime DataCriacao
        {
            get { return _dataCriacao; }
            protected set
            {
                if (value == null)
                    throw new Exception("Informe a data de criação do registro.");

                _dataCriacao = value;
            }
        }
    }
}

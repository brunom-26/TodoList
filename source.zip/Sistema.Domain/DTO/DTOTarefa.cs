﻿using Sistema.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Domain.DTO
{
    public struct DTOTarefa
    {
        private long _id;
        private DateTime _dataTarefa;
        private string _textoTarefa;
        private string _nomeTipoTarefa;
        private long _idTipoTarefa;
        private int _statusTarefa;
        

        public long id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public DateTime DataTarefa
        {
            get
            {
                return _dataTarefa;
            }
            set
            {
                _dataTarefa = value;
            }
        }

        public string TextoTarefa
        {
            get
            {
                return _textoTarefa;
            }
            set
            {
                _textoTarefa = value;
            }
        }

        public string NomeTipoTarefa
        {
            get
            {
                return _nomeTipoTarefa;
            }
            set
            {
                _nomeTipoTarefa = value;
            }
        }

        public long IdTipoTarefa
        {
            get
            {
                return _idTipoTarefa;
            }
            set
            {
                _idTipoTarefa = value;
            }
        }

        public string StatusTarefa
        {
            get
            {
                return ((StatusTarefa)_statusTarefa).ToString();
            }
            
        }
    }
}

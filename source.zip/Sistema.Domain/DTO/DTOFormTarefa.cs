﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Domain.DTO
{
    public struct DTOFormTarefa
    {
        private long _id;
        private string _dataTarefa;
        private string _textoTarefa;
        private long _idTipoTarefa;

        public long id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public string DataTarefa
        {
            get
            {
                return _dataTarefa;
            }
            set
            {
                _dataTarefa = value;
            }
        }

        public string TextoTarefa
        {
            get
            {
                return _textoTarefa;
            }
            set
            {
                _textoTarefa = value;
            }
        }

        public long IdTipoTarefa
        {
            get
            {
                return _idTipoTarefa;
            }
            set
            {
                _idTipoTarefa = value;
            }
        }
    }
}

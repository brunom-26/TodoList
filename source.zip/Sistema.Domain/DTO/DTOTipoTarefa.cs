﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Domain.DTO
{
    public struct DTOTipoTarefa
    {
        private long _id;
        private string _nomeTipoTarefa;

        public long id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public string NomeTipoTarefa
        {
            get
            {
                return _nomeTipoTarefa;
            }
            set
            {
                _nomeTipoTarefa = value;
            }
        }
    }
}

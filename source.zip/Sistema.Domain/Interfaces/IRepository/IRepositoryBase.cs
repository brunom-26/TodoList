﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Domain.Interfaces.IRepository
{
    public interface IRepositoryBase<T> : IDisposable where T : class
    {
        void Salvar(T entidade);
        void Remover(T entidade);
        T BuscarPor(long id);
        IList<T> BuscarTodos();
    }
}

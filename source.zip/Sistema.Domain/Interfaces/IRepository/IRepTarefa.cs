﻿using Sistema.Domain.DTO;
using Sistema.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Domain.Interfaces.IRepository
{
    public interface IRepTarefa : IRepositoryBase<Tarefa>
    {
        IList<DTOTarefa> ListarTarefas(DateTime data, StatusTarefa status);

    }
}

﻿using Sistema.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Domain.Interfaces.IApplication
{
    public interface IAppTipoTarefa
    {
        void Salvar(TipoTarefa tipoTarefa);
        void Remover(long id);
        TipoTarefa BuscarPor(long id);
        IList<TipoTarefa> BuscarTodos();
    }
}

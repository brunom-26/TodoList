﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Domain.Interfaces.IApplication
{
    public interface IAppBase<T> : IDisposable where T : class
    {

        T GetById(long id);
        long Insert(T entity);
        bool Update(T entity);
        bool Delete(T entity);
        IEnumerable<T> Find(Expression<Func<T, bool>> predicate);
        IEnumerable<T> GetAll();
    }
}

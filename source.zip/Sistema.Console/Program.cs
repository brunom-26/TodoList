﻿using Sistema.Application;
using Sistema.CrossCutting.Util;
using Sistema.Domain.Entities;
using Sistema.Domain.Entities.Enum;
using Sistema.Domain.Interfaces.IApplication;
using Sistema.Infra.Log;
using Sistema.Infra.Repositorio;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Sistema.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                if (args == null || args.Count() <= 0)
                    throw new Exception("Não foi definido parametro para execução.");

                switch (args[0])
                {
                    case "1":
                        ExecutarImportacaoRegra();
                        break;

                    case "2":
                        ExecutarExportarAcordo();
                        break;

                    case "3":
                        ExecutarExportarPagamento();
                        break;

                    case "4":
                        ExecutarImportacaoRemessa();
                        break;

                    case "5":
                        ExecutarImportacaoCNAB();
                        break;

                    case "6":
                        EnviarEmailParcelasAVencer();
                        break;

                    case "7":
                        GerarExcel();
                        break;
                }

                Environment.Exit(0);
            }
            catch (Exception ex)
            {

                IAppConfiguracao appConfiguracao = new AppConfiguracao();
                ItemConfiguracao itemDiretorio = appConfiguracao.GetByConfiguracao(Configuracao.DIRETORIO_LOG_CONSOLE);

                string diretorioLog = "";

                if (itemDiretorio != null && itemDiretorio.Valor != null)
                    diretorioLog = itemDiretorio.Valor.ValorTexto;

                Arquivo.CriarArquivoLog(ex, diretorioLog);
                Environment.Exit(1);
            }
        }
        private static void ExecutarImportacaoCNAB()
        {
            IAppCnab240 app = new AppCnab240();
            IAppConfiguracao appConfiguracao = new AppConfiguracao();

            ItemConfiguracao itemDiretorio = appConfiguracao.GetByConfiguracao(Configuracao.DIRETORIO_IMPORTACAO_CNAB);

            string diretorio = "";
            if (itemDiretorio != null && itemDiretorio.Valor != null)
                diretorio = itemDiretorio.Valor.ValorTexto;

            string[] arquivos = Directory.GetFiles(diretorio);

            string diretiorioSucesso = diretorio.Substring(0, diretorio.LastIndexOf(@"\")) + @"\Sucesso",
                   diretorioErro = diretorio.Substring(0, diretorio.LastIndexOf(@"\")) + @"\Erro";
           
            if (!string.IsNullOrEmpty(diretiorioSucesso))
                Arquivo.CriarDiretorio(diretiorioSucesso);

            if (!string.IsNullOrEmpty(diretorioErro))
                Arquivo.CriarDiretorio(diretorioErro);

            bool arquivoValido;

            foreach (string arquivo in arquivos)
            {
                arquivoValido = true;
                app.ExecutarImportacao(arquivo, ref arquivoValido);

                var nomeArquivo = System.IO.Path.GetFileName(arquivo);
                var destino = System.IO.Path.Combine(arquivoValido ? diretiorioSucesso : diretorioErro, nomeArquivo);

                System.IO.File.Copy(arquivo, destino, true);
                System.IO.File.Delete(arquivo);
            }
        }

        private static void ExecutarImportacaoRemessa()
        {
            IAppRemessaCobranca app = new AppRemessaCobranca();
            IAppConfiguracao appConfiguracao = new AppConfiguracao();

            ItemConfiguracao itemDiretorio = appConfiguracao.GetByConfiguracao(Configuracao.DIRETORIO_IMPORTACAO_REMESSA);

            string diretorio = "";
            if (itemDiretorio != null && itemDiretorio.Valor != null)
                diretorio = itemDiretorio.Valor.ValorTexto;

            string[] arquivos = Directory.GetFiles(diretorio);

            string diretiorioSucesso = diretorio.Substring(0, diretorio.LastIndexOf(@"\")) + @"\Sucesso",
                   diretorioErro = diretorio.Substring(0, diretorio.LastIndexOf(@"\")) + @"\Erro";

            if (!string.IsNullOrEmpty(diretiorioSucesso))
                Arquivo.CriarDiretorio(diretiorioSucesso);

            if (!string.IsNullOrEmpty(diretorioErro))
                Arquivo.CriarDiretorio(diretorioErro);

            bool arquivoValido;

            foreach (string arquivo in arquivos)
            {
                arquivoValido = true;
                app.ExecutarImportacao(arquivo, ref arquivoValido);

                var nomeArquivo = System.IO.Path.GetFileName(arquivo);
                var destino = System.IO.Path.Combine(arquivoValido ? diretiorioSucesso : diretorioErro, nomeArquivo);

                System.IO.File.Copy(arquivo, destino, true);
                System.IO.File.Delete(arquivo);
            }
        }

        private static void ExecutarExportarAcordo()
        {
            IAppConfiguracao appConfiguracao = new AppConfiguracao();
            ItemConfiguracao itemDiretorio = appConfiguracao.GetByConfiguracao(Configuracao.DIRETORIO_EXPORTACAO_ACORDO);
            ItemConfiguracao itemArquivo = appConfiguracao.GetByConfiguracao(Configuracao.ARQUIVO_RETORNO_ACORDO);
            ItemConfiguracao itemQtdAcordos = appConfiguracao.GetByConfiguracao(Configuracao.QTD_ACORDOS_MAXIMO_ARQUIVO);

            var erros = new List<string>();

            //valida exisência parâmetros.
            if (itemDiretorio == null || itemDiretorio.Valor == null || string.IsNullOrEmpty(itemDiretorio.Valor.ValorTexto))
                erros.Add("Parâmetro \"Diretório\" não encontrado");

            if (itemArquivo == null || itemArquivo.Valor == null || string.IsNullOrEmpty(itemArquivo.Valor.ValorTexto))
                erros.Add("Parâmetro \"Arquivo\" não encontrado");

            if (itemQtdAcordos == null || itemQtdAcordos.Valor == null || !itemQtdAcordos.Valor.ValorInteiro.HasValue || itemQtdAcordos.Valor.ValorInteiro.Value == 0)
                erros.Add("Parâmetro \"Qtde. Acordos\" não encontrado");

            //variável declarada próximo ao uso facilita entendimento/leitura.
            var logger = new LogComLote<AppRetornoAcordo>();

            //Loga todos os erros
            foreach (var msg in erros)
                logger.Warn(msg);

            //Se algum parâmetro não foi encontrado, não é possível prosseguir e um erro é gerado
            if (erros.Any())
                throw new Exception("Parâmetros de exportação de acordos não encontrados");

            //Se execução chegou até aqui, é pq todos os parâmetros estão ok.
            var path = itemDiretorio.Valor.ValorTexto;
            var max = itemQtdAcordos.Valor.ValorInteiro.Value;

            var app = new AppRetornoAcordo(new RepAcordo(), new RepAcordoLote(), new RepAcordoLoteItem(), appConfiguracao);
            app.ExecutarExportacao(path, max);
        }

        private static void ExecutarExportarPagamento()
        {
            IAppConfiguracao appConfiguracao = new AppConfiguracao();
            ItemConfiguracao itemDiretorio = appConfiguracao.GetByConfiguracao(Configuracao.DIRETORIO_EXPORTACAO_PAGAMENTO);
            ItemConfiguracao itemArquivo = appConfiguracao.GetByConfiguracao(Configuracao.ARQUIVO_RETORNO_PAGAMENTO);
            ItemConfiguracao itemQtd = appConfiguracao.GetByConfiguracao(Configuracao.QTD_PAGAMENTOS_MAXIMO_ARQUIVO);

            var erros = new List<string>();

            //valida exisência parâmetros.
            if (itemDiretorio == null || itemDiretorio.Valor == null || string.IsNullOrEmpty(itemDiretorio.Valor.ValorTexto))
                erros.Add("Parâmetro \"Diretório\" não encontrado");

            if (itemArquivo == null || itemArquivo.Valor == null || string.IsNullOrEmpty(itemArquivo.Valor.ValorTexto))
                erros.Add("Parâmetro \"Arquivo\" não encontrado");

            if (itemQtd == null || itemQtd.Valor == null || !itemQtd.Valor.ValorInteiro.HasValue || itemQtd.Valor.ValorInteiro.Value == 0)
                erros.Add("Parâmetro \"Qtde. Pagamentos\" não encontrado");

            //variável declarada próximo ao uso facilita entendimento/leitura.
            var logger = new LogComLote<AppRetornoPagamento>();

            //Loga todos os erros
            foreach (var msg in erros)
                logger.Warn(msg);

            //Se algum parâmetro não foi encontrado, não é possível prosseguir e um erro é gerado
            if (erros.Any())
                throw new Exception("Parâmetros de exportação de pagamentos não encontrados");

            //Se execução chegou até aqui, é pq todos os parâmetros estão ok.
            var path = itemDiretorio.Valor.ValorTexto;
            var max = itemQtd.Valor.ValorInteiro.Value;

            var app = new AppRetornoPagamento(new RepPagamento(), new RepPagamentoLote(), new RepPagamentoLoteItem(), appConfiguracao);
            app.ExecutarExportacao(path, max);
        }

        private static void ExecutarImportacaoRegra()
        {
            IAppConfiguracao appConfiguracao = new AppConfiguracao();
            ItemConfiguracao itemDiretorio = appConfiguracao.GetByConfiguracao(Configuracao.DIRETORIO_IMPORTACAO_REGRA);

            var diretorio = "";
            if (itemDiretorio != null && itemDiretorio.Valor != null)
                diretorio = itemDiretorio.Valor.ValorTexto;

            //Caso o diretório não esteja configurado o sistema cria um log de execução informando o caso e envia e-mail aos envolvidos
            IAppImportacao app = new AppImportacao();

            if (string.IsNullOrEmpty(diretorio))
                app.CriarLogErroDiretorio();

            var arquivos = Directory.GetFiles(diretorio);

            //Caso o diretório não não tenha nenhum arquivo para importação cria um log de execução informando a execução
            if (arquivos.Count() <= 0)
                app.CriarLogSemArquivo();

            foreach (string arquivo in arquivos)
                app.ExecutarImportacao(arquivo); //Os arquivos estão sendo movidos na execução do método
        }

        private static void EnviarEmailParcelasAVencer()
        {
            IAppConfiguracao appConfiguracao = new AppConfiguracao();

            var logger = new LogComLote<AppNotificacaoCliente>();
            var app = new AppNotificacaoCliente(new RepBoleto(), new RepAcordoParcela(), appConfiguracao);

            try
            {
                app.NotificarClienterComParcelasAVencer();
            }
            catch (Exception ex)
            {
                logger.Erro("Erro na notificação de clientes via email sobre parcelas a vencer", ex);
                throw;
            }
        }

        private static void GerarExcel()
        {
            var appConfiguracao = new AppConfiguracao();
            var logger = new LogComLote<AppExportacaoExcel>();

            try
            {
                var app = new AppExportacaoExcel();
                app.ExecutarExportacaoExcelAcordosAtivos(appConfiguracao);
                logger.Info(string.Format("Excel acordos ativos gerado com sucesso em '{0}'", appConfiguracao.GetPathExcelAcordos));
            }
            catch (Exception ex)
            {
                logger.Erro("Erro exportação excel acordos", ex);
                throw;
            }


            try
            {
                var app = new AppExportacaoExcel();
                app.ExecutarExportacaoExcelCNAB(appConfiguracao);
                logger.Info(string.Format("Excel CNAB gerado com sucesso em '{0}'", appConfiguracao.GetPathExcelCNAB));
            }
            catch (Exception ex)
            {
                logger.Erro("Erro exportação excel CNAB", ex);
                throw;
            }
        }
    }
}

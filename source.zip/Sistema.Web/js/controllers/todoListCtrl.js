angular.module("todoList").controller("todoListCtrl", function ($scope, tarefasAPI) {
    $scope.app = "Todo List";
    $scope.tipoTarefas = {};
    $scope.tarefa = {};

	$scope.salvarTarefa  = function () {

	    console.log("Salvar CTRL");
	    console.log($scope.tarefa);

	    tarefasAPI.salvarTarefa($scope.tarefa).then(function (data) {
			delete $scope.tarefa;
			$scope.carregarTarefas();
	    }).catch(function (data) {
	        alert("Erro ao salvar tarefa | " + data)
	    });
	};
	
	$scope.excluirTarefa  = function (tarefa) {

	    tarefasAPI.excluirTarefa(tarefa.id).then(function (data) {
			delete $scope.tarefa;
			$scope.carregarTarefas();
	    }).catch(function (data) {
	        alert("Erro ao excluir tarefa | " + data)
	    });
	};
	
	$scope.cancelarTarefa  = function (tarefa) {

	    console.log("CTRL");
	    console.log(tarefa);
	    tarefasAPI.cancelareTarefa(tarefa.id).then(function (data) {
			delete $scope.tarefa;
			$scope.carregarTarefas();
	    }).catch(function (data) {
	        alert("Erro ao cancelar tarefa | " + data)
	    });
	};
	
	$scope.encerrarTarefa  = function (tarefa) {

	    tarefasAPI.encerrarTarefa(tarefa.id).then(function (data) {
			delete $scope.tarefa;
			$scope.carregarTarefas();
	    }).catch(function (data) {
	        alert("Erro ao encerrar tarefa | " + data)
	    });
	};
	
		
	$scope.carregaTipoTarefas  = function () {

		tarefasAPI.carregaTipoTarefas().success(function (data) {
		    $scope.tipoTarefas = data;
		});
	};
	
	$scope.carregarTarefas  = function () {

		tarefasAPI.carregarTarefas(1).success(function (data) {
			$scope.tarefasPendentes = data;
		});
		
		tarefasAPI.carregarTarefas(2).success(function (data) {
			$scope.tarefasEncerradas = data;
		});
		
		tarefasAPI.carregarTarefas(3).success(function (data) {
			$scope.tarefasCanceladas = data;
		});
	};

	$scope.carregaTipoTarefas();
	$scope.carregarTarefas();
	
});
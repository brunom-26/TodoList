angular.module("todoList").config(function ($routeProvider) {
	$routeProvider.when("/todo", {
		templateUrl: "view/todolist.html",
		controller: "todoListCtrl",
	});
	$routeProvider.otherwise({redirectTo: "/todo"});
});
angular.module("todoList", ["ngMessages", "ui", "ngRoute"]);


$(document).ready(function () {
    //$('.date').mask('11/11/1111');
    $('#dataTarefa').mask('99/99/9999');
});
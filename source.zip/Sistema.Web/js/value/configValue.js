angular.module("todoList").value("config", {
	baseUrl: "http://localhost:4136"
});
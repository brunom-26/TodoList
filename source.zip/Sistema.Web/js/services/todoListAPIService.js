angular.module("todoList").factory("tarefasAPI", function ($http, config) {
	
	var _carregarTarefas = function (status) {
		return $http.get(config.baseUrl + "/tarefa/Listar/" + status);
	};

	var _salvarTarefa = function (tarefa) {
	    
	    tarefa.IdTipoTarefa = tarefa.TipoTarefa.id;

	    console.log(tarefa.NomeTipoTarefa);
	    console.log("Salvar service");
	    console.log(tarefa);

	    return $http.post(config.baseUrl + "/tarefa/Salvar/", tarefa);
	};
	
	
	var _excluirTarefa = function (id) {
		return $http.delete(config.baseUrl + "/tarefa/Excluir/" + id);
	};
		
	var _encerrarTarefa = function (id) {

	    console.log("Service");
	    console.log(id);
	    
	    return $http.put(config.baseUrl + "/Tarefa/Encerrar/" + id, {},  {});
	};
	
	var _cancelareTarefa = function (id) {
	    return $http.put(config.baseUrl + "/tarefa/Cancelar/" + id, {}, {});
	};
	
	var _carregaTipoTarefas = function () {
	    return $http.get(config.baseUrl + "/tarefa/BuscarTiposTarefa");
	};
	
	return {
		carregarTarefas: _carregarTarefas,
		salvarTarefa: _salvarTarefa,
		excluirTarefa: _excluirTarefa,
		encerrarTarefa: _encerrarTarefa,
		cancelareTarefa: _cancelareTarefa,
		carregaTipoTarefas: _carregaTipoTarefas
	};
});